<?php

return [
    'site_title' => 'Expense Manager',
];
