<?php $__env->startSection('content'); ?>

<div class="card">
    <div class="card-header">
        <?php echo e(trans('global.create')); ?> <?php echo e(trans('cruds.expense.title_singular')); ?>

    </div>

    <div class="card-body">
        <form action="<?php echo e(route("admin.expenses.store")); ?>" method="POST" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
            <div class="form-group <?php echo e($errors->has('expense_category_id') ? 'has-error' : ''); ?>">
                <label for="expense_category"><?php echo e(trans('cruds.expense.fields.expense_category')); ?></label>
                <select name="expense_category_id" id="expense_category" class="form-control select2">
                    <?php $__currentLoopData = $expense_categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $id => $expense_category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($id); ?>" <?php echo e((isset($expense) && $expense->expense_category ? $expense->expense_category->id : old('expense_category_id')) == $id ? 'selected' : ''); ?>><?php echo e($expense_category); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
                <?php if($errors->has('expense_category_id')): ?>
                    <em class="invalid-feedback">
                        <?php echo e($errors->first('expense_category_id')); ?>

                    </em>
                <?php endif; ?>
            </div>
            <div class="form-group <?php echo e($errors->has('entry_date') ? 'has-error' : ''); ?>">
                <label for="entry_date"><?php echo e(trans('cruds.expense.fields.entry_date')); ?>*</label>
                <input type="text" id="entry_date" name="entry_date" class="form-control date" value="<?php echo e(old('entry_date', isset($expense) ? $expense->entry_date : '')); ?>" required>
                <?php if($errors->has('entry_date')): ?>
                    <em class="invalid-feedback">
                        <?php echo e($errors->first('entry_date')); ?>

                    </em>
                <?php endif; ?>
                <p class="helper-block">
                    <?php echo e(trans('cruds.expense.fields.entry_date_helper')); ?>

                </p>
            </div>
            <div class="form-group <?php echo e($errors->has('amount') ? 'has-error' : ''); ?>">
                <label for="amount"><?php echo e(trans('cruds.expense.fields.amount')); ?>*</label>
                <input type="number" id="amount" name="amount" class="form-control" value="<?php echo e(old('amount', isset($expense) ? $expense->amount : '')); ?>" step="0.01" required>
                <?php if($errors->has('amount')): ?>
                    <em class="invalid-feedback">
                        <?php echo e($errors->first('amount')); ?>

                    </em>
                <?php endif; ?>
                <p class="helper-block">
                    <?php echo e(trans('cruds.expense.fields.amount_helper')); ?>

                </p>
            </div>
            <div class="form-group <?php echo e($errors->has('description') ? 'has-error' : ''); ?>">
                <label for="description"><?php echo e(trans('cruds.expense.fields.description')); ?></label>
                <input type="text" id="description" name="description" class="form-control" value="<?php echo e(old('description', isset($expense) ? $expense->description : '')); ?>">
                <?php if($errors->has('description')): ?>
                    <em class="invalid-feedback">
                        <?php echo e($errors->first('description')); ?>

                    </em>
                <?php endif; ?>
                <p class="helper-block">
                    <?php echo e(trans('cruds.expense.fields.description_helper')); ?>

                </p>
            </div>
            <div>
                <input class="btn btn-danger" type="submit" value="<?php echo e(trans('global.save')); ?>">
            </div>
        </form>


    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Volumes/Drive D/NOT JUST WEB/APPS/QuickAdminPanel-ExpenseManager/resources/views/admin/expenses/create.blade.php ENDPATH**/ ?>